const fs = require('node:fs');
const path = require('node:path');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const execFileAsync = promisify(execFile);
const { normalizeImageAcceleration } = require('./agent.cjs');
const busyPhases = new Set(['preparing', 'backing-up', 'installing', 'rolling-back']);

async function upgradeUpdater(dir, dependencies = {}) {
  const updater = path.join(path.resolve(dir), 'updater');
  const configFile = path.join(updater, 'config.json');
  const agentFile = path.join(updater, 'agent.cjs');
  const config = JSON.parse(fs.readFileSync(configFile, 'utf8'));
  if (!/^[a-z][a-z0-9-]{0,30}$/.test(config.project || '') || !config.stateFile || !fs.existsSync(agentFile)) throw new Error('未找到通用安装器创建的更新服务');
  const state = () => JSON.parse(fs.readFileSync(config.stateFile, 'utf8'));
  if (busyPhases.has(state().phase)) throw new Error('当前更新任务进行中或曾中断，请先完成或恢复更新');
  const source = dependencies.sourceFile || path.join(__dirname, 'agent.cjs');
  const replacement = fs.readFileSync(source);
  if (!replacement.includes(Buffer.from('normalizeImageAcceleration'))) throw new Error('安装包的更新器不支持镜像加速');
  const run = dependencies.run || (async (command, args) => (await execFileAsync(command, args, { timeout: 30000, maxBuffer: 1024 * 1024 })).stdout);
  const nextAcceleration = dependencies.imageAcceleration === undefined ? undefined : normalizeImageAcceleration(dependencies.imageAcceleration);
  const probe = dependencies.probe || (async () => {
    const host = config.bind === '0.0.0.0' ? '127.0.0.1' : config.bind;
    const token = fs.readFileSync(config.tokenFile, 'utf8').trim();
    const response = await fetch(`http://${host}:${config.port}/status`, { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(1500) });
    if (!response.ok || !(await response.json()).capabilities?.imageAcceleration) throw new Error('更新器接口尚未就绪或版本不正确');
  });
  const unit = `${config.project}-online-update.service`;
  const backup = path.join(updater, 'backups', `${Date.now()}-updater-upgrade`);
  fs.mkdirSync(backup, { recursive: true, mode: 0o700 });
  fs.copyFileSync(agentFile, path.join(backup, 'agent.cjs'));
  const oldConfig = fs.readFileSync(configFile);
  fs.copyFileSync(configFile, path.join(backup, 'config.json'));
  let stopped = false;
  try {
    await run('systemctl', ['stop', unit]);
    stopped = true;
    // Refuse a task that started between the initial check and service shutdown.
    if (busyPhases.has(state().phase)) throw new Error('升级前出现新的更新任务，已保留原更新器；请先恢复更新状态');
    const temporary = `${agentFile}.${process.pid}.tmp`;
    fs.writeFileSync(temporary, replacement, { mode: 0o600 });
    fs.renameSync(temporary, agentFile);
    const expectedConfig = nextAcceleration === undefined ? oldConfig : Buffer.from(JSON.stringify({ ...config, imageAcceleration: nextAcceleration }, null, 2));
    if (nextAcceleration !== undefined) {
      fs.writeFileSync(`${configFile}.${process.pid}.tmp`, expectedConfig, { mode: 0o600 });
      fs.renameSync(`${configFile}.${process.pid}.tmp`, configFile);
    }
    await run('systemctl', ['start', unit]);
    await run('systemctl', ['is-active', '--quiet', unit]);
    let probeError;
    for (let attempt = 0; attempt < 10; attempt++) {
      try { await probe(); probeError = null; break; }
      catch (error) {
        probeError = error;
        if (attempt < 9) await (dependencies.delay || (ms => new Promise(resolve => setTimeout(resolve, ms))))(500);
      }
    }
    if (probeError) throw new Error('新版更新器接口未就绪，已尝试恢复原更新器');
    if (!fs.readFileSync(configFile).equals(expectedConfig)) throw new Error('更新器配置意外变化，需检查后重试');
  } catch (error) {
    if (stopped) {
      try {
        await run('systemctl', ['stop', unit]);
        fs.copyFileSync(path.join(backup, 'agent.cjs'), agentFile);
        fs.writeFileSync(configFile, oldConfig, { mode: 0o600 });
        await run('systemctl', ['start', unit]);
      }
      catch (restartError) { throw new Error(`${error.message}；原更新器恢复启动失败：${restartError.message}，备份：${backup}`); }
    }
    throw error;
  }
  return { upgraded: true, backup, service: unit };
}
module.exports = { upgradeUpdater };
