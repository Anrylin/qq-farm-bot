#!/usr/bin/env bash
set -euo pipefail
installer_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if ! command -v node >/dev/null 2>&1; then
  echo '请先安装 Node.js 20 或更新版本，再重新运行安装脚本。' >&2
  exit 1
fi
# Serialize installations across instances so two installers cannot claim the same
# Docker resources or systemd unit while their first image downloads are running.
for installer_arg in "$@"; do
  if [[ "$installer_arg" == '--plan' || "$installer_arg" == '--help' ]]; then
    exec node "$installer_dir/install.cjs" "$@"
  fi
done
if [[ "$EUID" -eq 0 ]]; then
  if ! command -v flock >/dev/null 2>&1; then
    echo '请先安装 util-linux（提供 flock）。' >&2
    exit 1
  fi
  exec flock --nonblock --conflict-exit-code 75 /run/lock/qqfarm-installer.lock node "$installer_dir/install.cjs" "$@"
fi
exec node "$installer_dir/install.cjs" "$@"
