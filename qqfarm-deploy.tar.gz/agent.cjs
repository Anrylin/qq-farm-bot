const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const execFileAsync = promisify(execFile);

function atomicJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temporary = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(value, null, 2), { mode: 0o600 });
  fs.renameSync(temporary, file);
}
function validRelease(release, imagePrefix, local = false) {
  if (!release || !/^[\w.-]{1,100}$/.test(release.version || '') || !Number.isFinite(Date.parse(release.publishedAt)))
    throw new Error('Invalid release version or timestamp');
  if (typeof release.image !== 'string' || !/^[a-zA-Z0-9_./:@-]+$/.test(release.image))
    throw new Error('Invalid release image');
  if (!local && !release.image.startsWith(`${imagePrefix}@sha256:`))
    throw new Error('Release image must use the configured registry and an immutable digest');
  if (!local && !/@sha256:[a-f0-9]{64}$/.test(release.image))
    throw new Error('Invalid image digest');
  if (release.sessionProtocol !== undefined && !/^[a-f0-9]{64}$/.test(release.sessionProtocol)) throw new Error('Invalid session protocol fingerprint');
  return { version: release.version, image: release.image, publishedAt: release.publishedAt, notes: String(release.notes || '').slice(0, 12000), commit: String(release.commit || '').slice(0, 40), ...(release.sessionProtocol ? { sessionProtocol: release.sessionProtocol } : {}), local };
}
async function githubRelease(config) {
  const headers = { Accept: 'application/vnd.github+json', 'User-Agent': 'farm-online-updater' };
  if (process.env.GH_UPDATE_TOKEN) headers.Authorization = `Bearer ${process.env.GH_UPDATE_TOKEN}`;
  const response = await fetch(`https://api.github.com/repos/${config.repo}/releases/latest`, { headers, signal: AbortSignal.timeout(15000) });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`GitHub release check returned ${response.status}`);
  const release = await response.json();
  const asset = release.assets?.find(item => item.name === 'farm-update.json');
  if (!asset) return null;
  const url = new URL(asset.browser_download_url);
  if (url.origin !== 'https://github.com' || !url.pathname.startsWith(`/${config.repo}/releases/download/`))
    throw new Error('Unexpected release manifest URL');
  // The official asset API can work where github.com Release downloads time out.
  // Prefer it without requiring a personal token; fall back to the browser URL.
  const candidates = [];
  if (Number.isSafeInteger(asset.id) && asset.id > 0)
    candidates.push({ url: `https://api.github.com/repos/${config.repo}/releases/assets/${asset.id}`, headers: { ...headers, Accept: 'application/octet-stream' } });
  candidates.push({ url: url.toString(), headers: { 'User-Agent': 'farm-online-updater' } });
  let lastError;
  for (const candidate of candidates) {
    try {
      const manifestResponse = await fetch(candidate.url, { headers: candidate.headers, signal: AbortSignal.timeout(10000) });
      if (!manifestResponse.ok) throw new Error(`Release manifest returned ${manifestResponse.status}`);
      const chunks = [];
      let size = 0;
      for await (const chunk of manifestResponse.body) {
        size += chunk.length;
        if (size > 65536) throw new Error('Release manifest is too large');
        chunks.push(Buffer.from(chunk));
      }
      const bytes = Buffer.concat(chunks);
      if (/^sha256:[a-f0-9]{64}$/.test(asset.digest || '') && `sha256:${crypto.createHash('sha256').update(bytes).digest('hex')}` !== asset.digest)
        throw new Error('Release manifest checksum does not match GitHub metadata');
      const manifest = JSON.parse(bytes.toString('utf8'));
      if (manifest.version !== release.tag_name) throw new Error('Release manifest does not match the tag');
      return validRelease(manifest, config.imagePrefix);
    } catch (error) { lastError = error; }
  }
  throw lastError || new Error('Release manifest download failed');
}
function normalizeImageAcceleration(value = {}) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('镜像加速设置无效');
  const enabled = value.enabled ?? false;
  const fallbackToDirect = value.fallbackToDirect ?? true;
  if (typeof enabled !== 'boolean' || typeof fallbackToDirect !== 'boolean' || (value.imageMirror !== undefined && typeof value.imageMirror !== 'string')) throw new Error('镜像加速开关或地址无效');
  let imageMirror = String(value.imageMirror || '').trim();
  if (imageMirror) {
    if (imageMirror.length > 500 || /[\s\\\u0000-\u001F\u007F]/.test(imageMirror)) throw new Error('镜像代理地址含不支持的字符');
    const url = new URL(imageMirror.includes('://') ? imageMirror : `https://${imageMirror}`);
    if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash || !url.hostname || !url.hostname.split('.').every(label => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label))
      || !/^\/(?:[a-z0-9][a-z0-9._-]*(?:\/[a-z0-9][a-z0-9._-]*)*)?\/?$/.test(url.pathname)
      || url.pathname.split('/').some(part => part === '.' || part === '..')) throw new Error('镜像代理须为 HTTPS 仓库地址，不能包含账号密码、参数或版本号');
    imageMirror = `${url.host}${url.pathname}`.replace(/\/+$/, '');
  }
  if (enabled && !imageMirror) throw new Error('启用镜像加速前请填写镜像代理地址');
  return { enabled, imageMirror, fallbackToDirect };
}
function acceleratedImage(image, acceleration) {
  if (!acceleration.enabled) return image;
  if (!/^ghcr\.io\/[a-z0-9._/-]+@sha256:[a-f0-9]{64}$/.test(image)) throw new Error('该镜像不支持 GHCR 加速');
  return `${acceleration.imageMirror}/${image.slice('ghcr.io/'.length)}`;
}
function createUpdater(config, dependencies = {}) {
  const run = dependencies.run || (async (command, args) => {
    const result = await execFileAsync(command, args, { timeout: 20 * 60 * 1000, maxBuffer: 4 * 1024 * 1024 });
    return result.stdout;
  });
  const remoteRelease = dependencies.remoteRelease || (() => githubRelease(config));
  let state = fs.existsSync(config.stateFile) ? JSON.parse(fs.readFileSync(config.stateFile)) : { phase: 'idle', installed: null, log: [] };
  // An interrupted update is left visible and blocks a new install until an operator recovers it.
  let task = null;
  let cache = null;
  const compose = ['compose', '-p', config.project, ...config.composeFiles.flatMap(file => ['-f', file]), '-f', config.overrideFile];
  function save(patch) { state = { ...state, ...patch, updatedAt: Date.now() }; atomicJson(config.stateFile, state); }
  function progress(phase, message) { save({ phase, log: [...(state.log || []), { at: Date.now(), message }].slice(-30) }); }
  const acceleration = () => normalizeImageAcceleration(config.imageAcceleration);
  function status() { return { ...state, running: !!task, capabilities: { imageAcceleration: true }, imageAcceleration: acceleration() }; }
  async function setAcceleration(value) {
    if (task || ['preparing', 'backing-up', 'installing', 'rolling-back'].includes(state.phase)) throw new Error('更新任务进行中，请稍后修改加速设置');
    if (!dependencies.configFile) throw new Error('更新服务未登记配置文件位置，请升级更新器');
    const next = normalizeImageAcceleration(value);
    atomicJson(dependencies.configFile, { ...config, imageAcceleration: next });
    config.imageAcceleration = next;
    cache = null;
    return next;
  }
  function selectImage(image) { atomicJson(config.overrideFile, { services: { [config.service]: { image } } }); }
  async function check(force = false) {
    if (!force && cache && Date.now() - cache.at < 10 * 60000)
      return { ...cache.data, status: status() };
    const local = fs.existsSync(config.catalogFile) ? JSON.parse(fs.readFileSync(config.catalogFile)).map(item => validRelease(item, config.imagePrefix, true)) : [];
    let remote = null;
    let sourceError = '';
    try { remote = await remoteRelease(); }
    catch (error) { sourceError = error.message; }
    const releases = [...local, ...(remote ? [remote] : [])].sort((a, b) => Date.parse(b.publishedAt) - Date.parse(a.publishedAt));
    const installed = state.installed;
    const latest = releases[0] || installed;
    const available = !!(latest && installed && latest.version !== installed.version && Date.parse(latest.publishedAt) > Date.parse(installed.publishedAt));
    const sessionCompatible = !config.sessionProtocol || !latest || latest.sessionProtocol === config.sessionProtocol;
    const data = { configured: true, repo: config.repo, installed, latest, available,
      sessionPreserving: !!config.sessionProtocol, sessionCompatible,
      maintenanceReason: sessionCompatible ? '' : '新版需要维护游戏连接服务，请先联系管理员安排升级；当前服务继续运行',
      sourceError, checkedAt: Date.now(), status: status(), capabilities: { imageAcceleration: true }, imageAcceleration: acceleration() };
    cache = { at: Date.now(), data };
    return data;
  }
  async function apply(release) {
    const previous = state.installed;
    const backup = path.join(config.backupsRoot, `${Date.now()}-${release.version}`);
    let stopped = false;
    let backupComplete = false;
    try {
      progress('preparing', '正在准备新版镜像');
      if (config.sessionProtocol && release.sessionProtocol !== config.sessionProtocol)
        throw new Error('新版游戏连接服务与当前会话宿主不兼容，请先安排维护并迁移会话宿主；本次未停止应用');
      let runtimeImage = release.image;
      if (!release.local) {
        const settings = acceleration();
        if (settings.enabled) {
          const mirrored = acceleratedImage(release.image, settings);
          try {
            progress('preparing', '正在通过镜像代理下载新版，保留原版摘要校验');
            await run('docker', ['pull', mirrored]);
            await run('docker', ['image', 'inspect', mirrored]);
            runtimeImage = mirrored;
          } catch {
            if (!settings.fallbackToDirect) throw new Error('镜像代理下载失败；已关闭直连回退，请检查代理地址或切换直连后重试');
            progress('preparing', '镜像代理不可用，正在回退 GHCR 直连下载');
            await run('docker', ['pull', release.image]);
          }
        } else await run('docker', ['pull', release.image]);
      }
      await run('docker', ['image', 'inspect', runtimeImage]);
      fs.mkdirSync(backup, { recursive: true });
      progress('backing-up', '正在暂停应用服务并备份账号数据');
      await run('docker', [...compose, 'stop', config.service]);
      stopped = true;
      await run('docker', ['cp', `${config.container}:/app/core/data`, path.join(backup, 'data')]);
      backupComplete = true;
      save({ backup });
      progress('installing', '正在安装新版并检查健康状态');
      selectImage(runtimeImage);
      await run('docker', [...compose, 'up', '-d', '--no-deps', '--no-build', '--force-recreate', '--wait', '--wait-timeout', '120', config.service]);
      save({ installed: { ...release, ...(runtimeImage !== release.image ? { runtimeImage } : {}) }, phase: 'completed', finishedAt: Date.now(), error: '', log: [...state.log, { at: Date.now(), message: '更新成功，服务健康检查通过' }] });
      cache = null;
    }
    catch (error) {
      const message = String(error.message || error).slice(0, 2000);
      if (stopped && previous) {
        progress('rolling-back', '新版未能正常启动，正在恢复旧版');
        try {
          await run('docker', [...compose, 'stop', config.service]);
          // Restore the consistent pre-update data snapshot before restarting the old image.
          if (backupComplete && fs.existsSync(path.join(backup, 'data'))) {
            const restore = "const fs=require('node:fs');for(const name of fs.readdirSync('/state'))fs.rmSync('/state/'+name,{recursive:true,force:true});fs.cpSync('/snapshot','/state',{recursive:true});";
            await run('docker', ['run', '--rm', '--entrypoint', 'node', '--mount', `type=volume,source=${config.dataVolume},target=/state`, '--mount', `type=bind,source=${path.join(backup, 'data')},target=/snapshot,readonly`, previous.runtimeImage || previous.image, '-e', restore]);
          }
          selectImage(previous.runtimeImage || previous.image);
          await run('docker', [...compose, 'up', '-d', '--no-deps', '--no-build', '--force-recreate', '--wait', '--wait-timeout', '120', config.service]);
          progress('failed', '更新失败，旧版服务已恢复');
          save({ error: message, finishedAt: Date.now() });
        }
        catch (rollbackError) { save({ phase: 'rollback-failed', error: `${message}; rollback: ${rollbackError.message}`, finishedAt: Date.now() }); }
      }
      else save({ phase: 'failed', error: message, finishedAt: Date.now() });
    }
  }
  async function install(version) {
    if (task) throw new Error('已有更新任务正在进行');
    if (['preparing', 'backing-up', 'installing', 'rolling-back'].includes(state.phase)) throw new Error('上次更新被中断，请先恢复服务状态');
    const info = await check();
    if (task) throw new Error('已有更新任务正在进行');
    if (!info.available || info.latest.version !== version) throw new Error('该版本不是当前可用的新版本，请重新检查');
    if (!state.installed) throw new Error('当前版本未登记，无法创建回退点');
    save({ phase: 'preparing', target: info.latest, error: '', log: [], startedAt: Date.now() });
    task = apply(info.latest).finally(() => { task = null; });
    return status();
  }
  return { check, install, status, setAcceleration, settled: () => task || Promise.resolve() };
}
function startServer(config, configFile) {
  if (!/^[\w.-]+\/[\w.-]+$/.test(config.repo)) throw new Error('Invalid repository');
  const token = fs.readFileSync(config.tokenFile, 'utf8').trim();
  if (token.length < 32) throw new Error('Update agent token is too short');
  const updater = createUpdater(config, { configFile });
  const server = http.createServer(async (req, res) => {
    const provided = String(req.headers.authorization || '').replace(/^Bearer /, '');
    const expected = Buffer.from(token);
    const received = Buffer.from(provided);
    const send = (status, data) => { res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(data)); };
    if (expected.length !== received.length || !crypto.timingSafeEqual(expected, received)) return send(401, { error: 'Unauthorized' });
    try {
      const url = new URL(req.url, 'http://localhost');
      if (req.method === 'GET' && url.pathname === '/check') return send(200, await updater.check(url.searchParams.get('force') === '1'));
      if (req.method === 'GET' && url.pathname === '/status') return send(200, updater.status());
      if (req.method === 'POST' && ['/install', '/acceleration'].includes(url.pathname)) {
        let body = '';
        for await (const chunk of req) {
          body += chunk;
          if (body.length > 4096) return send(413, { error: 'Body too large' });
        }
        const parsed = JSON.parse(body);
        if (url.pathname === '/acceleration') return send(200, await updater.setAcceleration({ enabled: parsed.enabled, imageMirror: parsed.imageMirror, fallbackToDirect: parsed.fallbackToDirect }));
        return send(202, await updater.install(parsed.version));
      }
      send(404, { error: 'Not found' });
    }
    catch (error) { send(409, { error: String(error.message || error).slice(0, 2000) }); }
  });
  server.listen(config.port, config.bind);
  return server;
}
module.exports = { createUpdater, validRelease, githubRelease, startServer, normalizeImageAcceleration, acceleratedImage };
if (require.main === module) startServer(JSON.parse(fs.readFileSync(process.argv[2], 'utf8')), process.argv[2]);
