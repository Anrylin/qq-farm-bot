const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const { githubRelease, validRelease, normalizeImageAcceleration } = require('./agent.cjs');
const execFileAsync = promisify(execFile);

const HELP = `用法：sudo bash install.sh [选项]
全新安装网站和在线更新服务（Linux amd64、systemd、Docker Compose v2、Node.js 20+）。
  --dir PATH          安装目录，默认 /opt/qqfarm（必须为空或不存在）
  --name NAME         实例名称，默认 qqfarm；多实例使用不同名称、目录和端口
  --port PORT         网站端口，默认 3007
  --bind IPv4         网站监听地址，默认 127.0.0.1；直接对外访问可用 0.0.0.0
  --repo OWNER/REPO   更新源，默认 Anrylin/qq-farm-bot
  --image-prefix IMAGE  镜像仓库，默认 ghcr.io/<repo小写>
  --resume            继续此目录中尚未完成的安装，不覆盖密钥或版本记录
  --upgrade-updater   仅升级已安装实例的更新器，保留配置、密钥、数据和会话容器
  --image-mirror PREFIX  配合 --upgrade-updater 启用 GHCR 镜像代理，失败回退直连
  --enable-sessions   为已安装实例启用独立会话容器（首次会断线，先网页升级到新版）
  --plan              只显示安装参数，不连接网络、不写文件、不操作 Docker
  --help              显示帮助
现有部署请先迁移数据；本脚本不会自动接管已有容器或数据卷。`;

function parseOptions(args) {
  const values = { dir: '/opt/qqfarm', name: 'qqfarm', port: 3007, bind: '127.0.0.1', repo: 'Anrylin/qq-farm-bot' };
  const flags = new Set(['--resume', '--plan', '--help', '--enable-sessions', '--upgrade-updater']);
  const keys = new Set(['--dir', '--name', '--port', '--bind', '--repo', '--image-prefix', '--image-mirror']);
  for (let i = 0; i < args.length; i++) {
    const key = args[i];
    if (flags.has(key)) values[key.slice(2)] = true;
    else if (keys.has(key) && args[i + 1] && !args[i + 1].startsWith('--')) values[key.slice(2)] = args[++i];
    else throw new Error(`未知选项或缺少参数：${key}\n${HELP}`);
  }
  if (!/^\/[A-Za-z0-9_./-]+$/.test(values.dir) || values.dir.split('/').includes('..') || path.resolve(values.dir) === '/')
    throw new Error('安装目录必须是绝对路径，仅支持英文、数字、下划线、点和连字符，不能含 ..');
  values.dir = path.resolve(values.dir);
  if (!/^[a-z][a-z0-9-]{0,30}$/.test(values.name)) throw new Error('实例名称应以小写字母开头，最多31位，仅支持小写字母、数字和连字符');
  if (!/^\d+$/.test(String(values.port)) || Number(values.port) < 1 || Number(values.port) > 65535) throw new Error('网站端口必须为 1–65535');
  values.port = Number(values.port);
  if (!net.isIPv4(values.bind)) throw new Error('监听地址必须为 IPv4 地址');
  if (!/^[A-Za-z0-9][A-Za-z0-9-]*\/[A-Za-z0-9_][A-Za-z0-9_.-]*$/.test(values.repo)) throw new Error('更新源格式必须为 OWNER/REPO');
  values.imagePrefix = values['image-prefix'] || `ghcr.io/${values.repo.toLowerCase()}`;
  if (!/^ghcr\.io\/[a-z0-9._-]+\/[a-z0-9._/-]+$/.test(values.imagePrefix)) throw new Error('镜像地址必须为小写的 ghcr.io/OWNER/IMAGE');
  delete values['image-prefix'];
  if (values['image-mirror'] !== undefined) {
    if (!values['upgrade-updater']) throw new Error('--image-mirror 目前仅用于 --upgrade-updater，安装完成后可在网页设置加速');
    values.imageAcceleration = normalizeImageAcceleration({ enabled: true, imageMirror: values['image-mirror'], fallbackToDirect: true });
    delete values['image-mirror'];
  }
  if (values['upgrade-updater'] && (values['enable-sessions'] || values.resume)) throw new Error('--upgrade-updater 不能与迁移或继续安装同时使用');
  return values;
}

function deployment(options, gateway, nodePath = process.execPath, release = {}) {
  const { dir, name, port, bind, repo, imagePrefix } = options;
  const updater = path.join(dir, 'updater');
  const serviceName = `${name}-online-update.service`;
  const network = `${name}-network`;
  const dataVolume = `${name}-data`;
  const container = `${name}-app`;
  const composeFile = path.join(dir, 'compose.json');
  const overrideFile = path.join(dir, 'compose.image.json');
  const tokenFile = path.join(updater, 'agent-token');
  const config = {
    repo, imagePrefix, bind: gateway, port: 3917, tokenFile,
    stateFile: path.join(updater, 'state.json'), catalogFile: path.join(updater, 'releases.json'),
    overrideFile, backupsRoot: path.join(updater, 'backups'),
    project: name, service: 'app', container, dataVolume, composeFiles: [composeFile],
  };
  const compose = {
    services: { app: {
      container_name: container, restart: 'unless-stopped',
      ports: [{ target: 3007, published: String(port), host_ip: bind }],
      environment: { NODE_ENV: 'production', TZ: 'Asia/Shanghai', ADMIN_PORT: '3007', UPDATE_AGENT_URL: `http://${gateway}:3917`, UPDATE_AGENT_TOKEN_FILE: '/run/qqfarm-update-token' },
      volumes: [
        { type: 'volume', source: 'data', target: '/app/core/data' },
        { type: 'bind', source: tokenFile, target: '/run/qqfarm-update-token', read_only: true },
      ],
      networks: ['runtime'],
      healthcheck: { test: ['CMD', 'wget', '-q', '--spider', 'http://127.0.0.1:3007/api/game-version'], interval: '30s', timeout: '10s', retries: 3, start_period: '20s' },
      logging: { driver: 'json-file', options: { 'max-size': '10m', 'max-file': '3' } },
    } },
    volumes: { data: { external: true, name: dataVolume } },
    networks: { runtime: { external: true, name: network } },
  };
  if (release.sessionProtocol) {
    config.sessionProtocol = release.sessionProtocol;
    config.runtimeVolume = `${name}-runtime`;
    const app = compose.services.app;
    app.environment.FARM_RUNTIME_DIR = '/app/runtime';
    app.environment.FARM_SESSION_SOCKET = '/app/runtime/session-host.sock';
    app.volumes.push({ type: 'volume', source: 'session-runtime', target: '/app/runtime' });
    app.depends_on = { 'session-host': { condition: 'service_healthy' } };
    compose.services['session-host'] = {
      image: release.image, restart: 'unless-stopped',
      command: ['node', 'dist/session/host.js'],
      environment: { TZ: 'Asia/Shanghai', FARM_HOST_DATA_DIR: '/app/runtime/session-host-data', FARM_RUNTIME_DIR: '/app/runtime', FARM_SESSION_SOCKET: '/app/runtime/session-host.sock' },
      volumes: [{ type: 'volume', source: 'session-runtime', target: '/app/runtime' }],
      networks: ['runtime'],
      healthcheck: { test: ['CMD', 'node', '-e', "require('./dist/session/ipc').SessionClient.open('control').then(c=>c.close()).catch(()=>process.exit(1))"], interval: '5s', timeout: '4s', retries: 5, start_period: '10s' },
      logging: app.logging,
    };
    compose.volumes['session-runtime'] = { external: true, name: config.runtimeVolume };
  }
  // Values used in systemd paths are restricted above; quote the Node executable separately.
  if (/[\r\n"\\%]/.test(nodePath)) throw new Error('Node.js 可执行文件路径含不支持的字符');
  const unit = `[Unit]\nDescription=QQ Farm online updater (${name})\nRequires=docker.service\nPartOf=docker.service\nAfter=docker.service network-online.target\nWants=network-online.target\n\n[Service]\nType=simple\nUser=root\nWorkingDirectory=${updater}\nExecStart="${nodePath}" ${updater}/agent.cjs ${updater}/config.json\nEnvironment=PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/snap/bin\nRestart=on-failure\nRestartSec=5\nUMask=0077\n\n[Install]\nWantedBy=multi-user.target\n`;
  return { config, compose, unit, serviceName, composeFile, overrideFile, updater, network, dataVolume, container };
}

function writeJson(file, value) {
  const temporary = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(temporary, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
  fs.renameSync(temporary, file);
}

async function install(inputOptions, dependencies = {}) {
  const run = dependencies.run || (async (command, args) => {
    try {
      const result = await execFileAsync(command, args, { timeout: 20 * 60 * 1000, maxBuffer: 4 * 1024 * 1024 });
      return result.stdout;
    } catch (error) {
      throw new Error(`${command} ${args.slice(0, 3).join(' ')} 失败：${String(error.stderr || error.message).slice(-2000)}`);
    }
  });
  const report = dependencies.report || console.log;
  const unitRoot = dependencies.unitRoot || '/etc/systemd/system';
  let options = inputOptions;
  const markerFile = path.join(options.dir, 'installation.json');
  let marker;
  if (options.resume) {
    if (!fs.existsSync(markerFile)) throw new Error('此目录没有可继续的安装记录');
    marker = JSON.parse(fs.readFileSync(markerFile, 'utf8'));
    if (marker.format !== 1 || marker.options.dir !== options.dir) throw new Error('安装记录无效');
    if (marker.phase === 'completed') throw new Error('安装已完成，请使用网站在线更新；无需重复运行安装器');
    // Do not allow command-line defaults to change the original instance during recovery.
    options = parseOptions(Object.entries(marker.options).flatMap(([key, value]) => [`--${key === 'imagePrefix' ? 'image-prefix' : key}`, String(value)]));
  } else if (fs.existsSync(options.dir) && fs.readdirSync(options.dir).length) {
    throw new Error('安装目录非空，已停止；未完成的本安装器部署可使用 --dir PATH --resume');
  }
  const initial = deployment(options, '127.0.0.1');
  const unitFile = path.join(unitRoot, initial.serviceName);
  if (!marker && fs.existsSync(unitFile)) throw new Error(`系统服务 ${initial.serviceName} 已存在，请更换 --name`);
  await run('docker', ['info']);
  await run('docker', ['compose', 'version']);
  const composeHelp = await run('docker', ['compose', 'up', '--help']);
  if (!composeHelp.includes('--wait-timeout')) throw new Error('Docker Compose 版本过旧，请升级到支持 --wait-timeout 的 Compose v2');
  await run('systemctl', ['show', '--property=Version', '--value']);

  const label = `io.qqfarm.installation=${options.dir}`;
  async function resource(kind, name, createArgs) {
    let existing;
    try { existing = JSON.parse(await run('docker', [kind, 'inspect', name]))[0]; }
    catch (error) {
      // The preflight above verified Docker. A failed inspect is handled by create, which also detects conflicts.
      if (!createArgs) throw error;
    }
    if (existing) {
      if (!marker || existing.Labels?.['io.qqfarm.installation'] !== options.dir) throw new Error(`${kind} ${name} 已存在且不属于此次安装，请更换 --name`);
      return existing;
    }
    await run('docker', [kind, 'create', '--label', label, ...createArgs, name]);
    return JSON.parse(await run('docker', [kind, 'inspect', name]))[0];
  }
  // Inspect all names before creating anything, so an existing deployment is never adopted.
  if (!marker) {
    for (const [kind, name] of [['container', initial.container], ['volume', initial.dataVolume], ['volume', `${options.name}-runtime`], ['network', initial.network]]) {
      let existing = false;
      try { await run('docker', [kind, 'inspect', name]); existing = true; } catch {}
      if (existing) throw new Error(`${kind} ${name} 已存在，请更换 --name；安装器不会接管现有数据`);
    }
  } else {
    let container;
    try { container = JSON.parse(await run('docker', ['container', 'inspect', initial.container]))[0]; } catch {}
    if (container && (container.Config?.Labels?.['com.docker.compose.project'] !== options.name || container.Config?.Labels?.['io.qqfarm.installation'] !== options.dir))
      throw new Error('同名容器不属于此次安装，拒绝继续');
  }
  const release = marker ? validRelease(marker.release, options.imagePrefix) : await (dependencies.release || githubRelease)(options);
  if (!release) throw new Error('更新源尚未发布带 farm-update.json 的正式版，请先发布再安装');
  validRelease(release, options.imagePrefix);
  report(`准备安装 ${options.repo} ${release.version}，首次下载镜像可能较慢……`);
  await run('docker', ['pull', release.image]);
  if (!marker) {
    fs.mkdirSync(options.dir, { recursive: true, mode: 0o700 });
    marker = { format: 1, phase: 'preparing', options: { dir: options.dir, name: options.name, port: options.port, bind: options.bind, repo: options.repo, imagePrefix: options.imagePrefix }, release };
    writeJson(markerFile, marker);
  }
  const bridge = await resource('network', initial.network, ['--driver', 'bridge']);
  const gateway = bridge.IPAM?.Config?.find(item => net.isIPv4(item.Gateway || ''))?.Gateway;
  if (!gateway) throw new Error('未找到 Docker 专用网络的 IPv4 网关');
  await resource('volume', initial.dataVolume, []);
  const files = deployment(options, gateway, process.execPath, release);
  if (files.config.runtimeVolume) await resource('volume', files.config.runtimeVolume, []);
  files.compose.services.app.labels = { 'io.qqfarm.installation': options.dir };
  fs.mkdirSync(files.updater, { recursive: true, mode: 0o700 });
  if (!fs.existsSync(files.config.tokenFile)) fs.writeFileSync(files.config.tokenFile, `${crypto.randomBytes(32).toString('hex')}\n`, { flag: 'wx', mode: 0o600 });
  if (fs.readFileSync(files.config.tokenFile, 'utf8').trim().length < 32) throw new Error('已有通信密钥无效；请检查安装目录');
  fs.copyFileSync(path.join(__dirname, 'agent.cjs'), path.join(files.updater, 'agent.cjs'));
  writeJson(path.join(files.updater, 'config.json'), files.config);
  writeJson(files.composeFile, files.compose);
  writeJson(files.overrideFile, { services: { app: { image: release.image } } });
  await run('docker', ['compose', '-p', options.name, '-f', files.composeFile, '-f', files.overrideFile, 'config', '--quiet']);
  // Do not register a version until the container has actually passed its health check.
  report('启动网站并等待健康检查……');
  await run('docker', ['compose', '-p', options.name, '-f', files.composeFile, '-f', files.overrideFile, 'up', '-d', '--no-build', '--wait', '--wait-timeout', '120', 'app']);
  if (!fs.existsSync(files.config.stateFile)) writeJson(files.config.stateFile, { phase: 'idle', installed: release, log: [] });
  if (!fs.existsSync(files.config.catalogFile)) writeJson(files.config.catalogFile, []);
  fs.writeFileSync(unitFile, files.unit, { mode: 0o644 });
  await run('systemctl', ['daemon-reload']);
  await run('systemctl', ['enable', '--now', files.serviceName]);
  await run('systemctl', ['is-active', '--quiet', files.serviceName]);
  // Check from inside the app network: verifies the token mount, bridge route and actual listener.
  const probe = "const fs=require('node:fs');fetch(process.env.UPDATE_AGENT_URL+'/status',{headers:{Authorization:'Bearer '+fs.readFileSync(process.env.UPDATE_AGENT_TOKEN_FILE,'utf8').trim()},signal:AbortSignal.timeout(5000)}).then(r=>{if(!r.ok)throw Error('update agent HTTP '+r.status);return r.json()}).then(s=>{if(!s.installed)throw Error('version not registered')}).catch(e=>{console.error(e.message);process.exit(1)})";
  let probeError;
  for (let attempt = 0; attempt < 5; attempt++) {
    try { await run('docker', ['exec', files.container, 'node', '-e', probe]); probeError = null; break; }
    catch (error) { probeError = error; if (attempt < 4) await (dependencies.delay || (ms => new Promise(resolve => setTimeout(resolve, ms))))(1000); }
  }
  if (probeError) throw new Error(`网站无法连接更新服务，请检查防火墙是否允许专用 Docker 网络访问网关的 3917 端口：${probeError.message}`);
  writeJson(markerFile, { ...marker, phase: 'completed', finishedAt: Date.now() });
  report(`安装完成：${release.version}\n网站：http://${options.bind === '0.0.0.0' ? '<服务器IP>' : options.bind}:${options.port}\n首次登录：admin / admin，请修改密码。\n以后进入「设置 → 系统 → 版本与在线更新」安装新版。\n安装目录：${options.dir}\n更新服务：${files.serviceName}\n备份目录：${files.config.backupsRoot}`);
  return files;
}

async function main(args) {
  const options = parseOptions(args);
  if (options.help) return console.log(HELP);
  if (options.plan) return console.log(JSON.stringify({ options, requirements: 'Linux amd64, systemd, Docker Compose v2, Node.js >=20', resources: deployment(options, '<专用Docker网络网关>') }, null, 2));
  if (process.platform !== 'linux' || process.arch !== 'x64') throw new Error('当前公开镜像安装方式支持 Linux amd64');
  if (Number(process.versions.node.split('.')[0]) < 20) throw new Error('需要 Node.js 20 或更新版本');
  if (process.getuid?.() !== 0) throw new Error('请使用 sudo bash install.sh 运行安装器');
  if (options['upgrade-updater']) {
    const result = await require('./upgrade.cjs').upgradeUpdater(options.dir, { imageAcceleration: options.imageAcceleration });
    console.log(`更新器已升级，应用和 QQ 会话容器未重启。备份：${result.backup}`);
    return result;
  }
  if (options['enable-sessions']) return require('./migrate-sessions.cjs').migrateSessions(options);
  return install(options);
}

module.exports = { parseOptions, deployment, install, main };
if (require.main === module) main(process.argv.slice(2)).catch(error => {
  if (process.argv.includes('--upgrade-updater')) {
    console.error(`更新器升级失败：${error.message}`);
    process.exitCode = 1;
    return;
  }
  console.error(`安装未完成：${error.message}\n已生成的数据不会自动删除。修复后可使用相同 --dir 并加 --resume 继续。`);
  process.exitCode = 1;
});
