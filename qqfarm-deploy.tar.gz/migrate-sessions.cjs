const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

// Upgrade only deployments originally created by this installer. An ordinary
// online update cannot change the old host updater's Compose topology safely.
async function migrateSessions(options) {
  const { deployment, parseOptions } = require('./install.cjs');
  const { dir } = options;
  const marker = JSON.parse(fs.readFileSync(path.join(dir, 'installation.json')));
  if (marker.format !== 1 || marker.phase !== 'completed' || marker.options.dir !== dir) throw new Error('仅支持已完成的通用安装器部署');
  const original = parseOptions(Object.entries(marker.options).flatMap(([key, value]) => [`--${key === 'imagePrefix' ? 'image-prefix' : key}`, String(value)]));
  const configFile = path.join(dir, 'updater/config.json');
  const config = JSON.parse(fs.readFileSync(configFile));
  const state = JSON.parse(fs.readFileSync(config.stateFile));
  if (['preparing', 'backing-up', 'installing', 'rolling-back'].includes(state.phase)) throw new Error('更新尚未结束，不能迁移');
  if (!state.installed?.sessionProtocol) {
    // v2026.11.23.4's agent discarded unknown manifest fields. Recover metadata
    // from the public source only when both the installed version and digest match.
    const release = await require('./agent.cjs').githubRelease(config);
    if (!release?.sessionProtocol || release.version !== state.installed?.version || release.image !== state.installed?.image)
      throw new Error('请先在网页升级到支持独立会话的最新正式版，再运行此次迁移');
    state.installed = release;
    require('./agent.cjs').validRelease(release, config.imagePrefix);
    fs.writeFileSync(config.stateFile, JSON.stringify(state, null, 2), { mode: 0o600 });
  }
  const migrationFile = path.join(dir, 'session-migration.json');
  if (fs.existsSync(migrationFile)) {
    const status = JSON.parse(fs.readFileSync(migrationFile));
    if (status.phase !== 'completed' && status.phase !== 'failed') throw new Error(`上次迁移被中断，请先按部署文档恢复 ${status.backup}`);
  }
  if (config.sessionProtocol) { console.log('此实例已启用独立会话服务，无需重复迁移。'); return; }
  const next = deployment(original, config.bind, process.execPath, state.installed);
  if (config.project !== next.config.project || config.container !== next.config.container || config.dataVolume !== next.config.dataVolume
      || config.composeFiles.length !== 1 || config.composeFiles[0] !== next.composeFile) throw new Error('部署配置已被手工修改，请按文档手工迁移');
  const currentCompose = JSON.parse(fs.readFileSync(next.composeFile));
  if (currentCompose.services['session-host'] || currentCompose.volumes['session-runtime']) throw new Error('发现未登记的会话配置，请先检查配置');
  const backup = path.join(dir, 'updater/backups', `${Date.now()}-session-migration`);
  const service = next.serviceName;
  const run = (command, args) => execFileSync(command, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 180000 });
  const compose = ['compose', '-p', config.project, '-f', next.composeFile, '-f', config.overrideFile];
  const write = (file, data) => {
    const temporary = `${file}.migration.tmp`;
    fs.writeFileSync(temporary, JSON.stringify(data, null, 2), { mode: 0o600 }); fs.renameSync(temporary, file);
  };
  // A pre-existing runtime volume is never adopted, even if it happens to share a name.
  let exists = false;
  try { run('docker', ['volume', 'inspect', next.config.runtimeVolume]); exists = true; } catch {}
  if (exists) throw new Error(`数据卷 ${next.config.runtimeVolume} 已存在，请先检查归属`);
  fs.mkdirSync(backup, { recursive: true, mode: 0o700 });
  for (const [name, source] of [['compose.json', next.composeFile], ['config.json', configFile], ['agent.cjs', path.join(next.updater, 'agent.cjs')]])
    fs.copyFileSync(source, path.join(backup, name));
  write(migrationFile, { phase: 'preparing', backup });
  let stopped = false;
  let volumeCreated = false;
  try {
    run('systemctl', ['stop', service]);
    run('docker', [...compose, 'stop', config.service]); stopped = true;
    run('docker', ['cp', `${config.container}:/app/core/data`, path.join(backup, 'data')]);
    run('docker', ['volume', 'create', '--label', `io.qqfarm.installation=${dir}`, next.config.runtimeVolume]); volumeCreated = true;
    const app = currentCompose.services[config.service];
    app.environment = { ...app.environment, FARM_RUNTIME_DIR: '/app/runtime', FARM_SESSION_SOCKET: '/app/runtime/session-host.sock' };
    app.volumes.push({ type: 'volume', source: 'session-runtime', target: '/app/runtime' });
    app.depends_on = { 'session-host': { condition: 'service_healthy' } };
    currentCompose.services['session-host'] = next.compose.services['session-host'];
    currentCompose.volumes['session-runtime'] = next.compose.volumes['session-runtime'];
    write(next.composeFile, currentCompose);
    // Keep all existing paths and source settings, pin only the new session host.
    write(configFile, { ...config, sessionProtocol: state.installed.sessionProtocol, runtimeVolume: next.config.runtimeVolume });
    fs.copyFileSync(path.join(__dirname, 'agent.cjs'), path.join(next.updater, 'agent.cjs'));
    run('docker', [...compose, 'config', '--quiet']);
    run('docker', [...compose, 'up', '-d', '--no-build', '--wait', '--wait-timeout', '120', 'session-host']);
    run('docker', [...compose, 'up', '-d', '--no-deps', '--no-build', '--wait', '--wait-timeout', '120', config.service]);
    run('systemctl', ['start', service]);
    run('systemctl', ['is-active', '--quiet', service]);
    write(migrationFile, { phase: 'completed', backup, finishedAt: Date.now() });
    console.log(`独立会话服务已启用。此次迁移后请重新登录游戏账号；后续兼容版本更新只重启应用容器。\n备份：${backup}`);
  } catch (error) {
    try {
      if (volumeCreated) {
        run('docker', [...compose, 'stop', config.service]);
        run('docker', [...compose, 'rm', '-s', '-f', 'session-host']);
        run('docker', ['volume', 'rm', next.config.runtimeVolume]);
      }
      fs.copyFileSync(path.join(backup, 'compose.json'), next.composeFile);
      fs.copyFileSync(path.join(backup, 'config.json'), configFile);
      fs.copyFileSync(path.join(backup, 'agent.cjs'), path.join(next.updater, 'agent.cjs'));
      if (stopped) run('docker', [...compose, 'up', '-d', '--no-deps', '--no-build', '--wait', '--wait-timeout', '120', config.service]);
      run('systemctl', ['start', service]);
      write(migrationFile, { phase: 'failed', backup, error: error.message });
    } catch (recovery) {
      throw new Error(`迁移失败且自动恢复未完成，请按文档恢复 ${backup}：${error.message}; ${recovery.message}`);
    }
    throw new Error(`迁移失败，已恢复原部署：${error.message}`);
  }
}
module.exports = { migrateSessions };
